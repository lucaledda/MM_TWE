// To compile the cpp for windows 64 bits
// i686-w64-mingw32-g++ -static-libgcc -static-libstdc++ -o BOM_TWE_Generator.exe BOM_TWE_Generator.cpp 

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <sstream>
#include <vector>
#include <windows.h>
#include <io.h>
#include <Strsafe.h>
#include <direct.h>
#include <regex>
#include <experimental/filesystem>
using namespace std;
namespace fs = std::experimental::filesystem::v1;

string projName;
string projPath;
string projCADPath;
string projBOMPath;
string MARELLI_custom_path;
string MARELLI_projects_path;
string MARELLI_lib1_path;
string MARELLI_models_path;
string disk;
string temp;
string component_line;
ifstream src;
ofstream dst;

string stringReplace(const string&, const string&, const string&);
void createTWE_BOM();
void createProjEnv();
void pullMasterLib();
void pushMasterLib();
void pullModelLib();
void pushModelLib();
void pullProject();
void pushProject();
string whichLocalDisk();
vector<string> parseLineByDelimiter(string, char);
void printVector(vector<string>);
string getVectorElement(vector<string>, int);
void deleteProjEnv();

int main() {
	int select = 0;

	/* Ask to the user the local disk TWE is installed into */
	disk = whichLocalDisk();

	/* Path definition */
	MARELLI_custom_path = disk + ":\\TestWay\\Data\\MARELLI\\CUSTOM\\";
	MARELLI_projects_path = disk + ":\\TestWay\\Data\\MARELLI\\PROJECTS\\";
	MARELLI_lib1_path = disk + ":\\TestWay\\Data\\MARELLI\\LIB1\\";
	MARELLI_models_path = disk + ":\\TestWay\\Data\\MARELLI\\MODELS\\";

	/* Menu */
	do {
		system("CLS");
		cout << " * * * * * * * * * * * * * * * * * * * * * * * " << endl;
		cout << " *                                           * " << endl;
		cout << " *  Insert number of choice and press ENTER  *" << endl;
		cout << " *                                           * " << endl;
		cout << " * * * * * * * * * * * * * * * * * * * * * * * " << endl;
		cout << " *                                           * " << endl;
		cout << " * 1 - Create Project environment            *" << endl;
		cout << " *                                           * " << endl;
		cout << " * 2 - Delete Project environment            *" << endl;
		cout << " *                                           * " << endl;
		cout << " * 3 - PULL masterLib                        *" << endl;
		cout << " *                                           * " << endl;
		cout << " * 4 - PULL modelLib                         *" << endl;
		cout << " *                                           * " << endl;
		cout << " * 5 - PULL a Project                        *" << endl;
		cout << " *                                           * " << endl;
		cout << " * 6 - PUSH masterLib                        *" << endl;
		cout << " *                                           * " << endl;
		cout << " * 7 - PUSH modelLib                         *" << endl;
		cout << " *                                           * " << endl;
		cout << " * 8 - PUSH a Project                        *" << endl;
		cout << " *                                           * " << endl;
		cout << " * * * * * * * * * * * * * * * * * * * * * * * " << endl;
		cout << " *                                           * " << endl;
		cout << " * 0 - EXIT                                  *" << endl;
		cout << " *                                           * " << endl;
		cout << " * * * * * * * * * * * * * * * * * * * * * * * " << endl << endl;
		cout << "Choice : ";
		cin >> select;
		cout << endl;
		switch (select) {
			case 1:
				createProjEnv();
				system("PAUSE");
				break;
			
			case 2:
				deleteProjEnv();
				system("PAUSE");
				break;

			case 3:
				pullMasterLib();
				system("PAUSE");
				break;

			case 4:
				pullModelLib();
				system("PAUSE");
				break;

			case 5:
				pullProject();
				system("PAUSE");
				break;

			case 6:
				pushMasterLib();
				system("PAUSE");
				break;

			case 7:
				pushModelLib();
				system("PAUSE");
				break;

			case 8:
				pushProject();
				system("PAUSE");
				break;

			case 0:
				cout << "Application closed." << endl;
				system("PAUSE");


				break;

		}
	} while (select != 0);
	return 0;
}
void createTWE_BOM() {
	/* --------------------------------------------------- VARIABLES ------------------------------------------------------------- */
	vector<string> array_fields;
	string component_line, percentage_value, nominal_value, zero = "0", line_to_write = "", tolerance_value, unit, projBOMfile, projBOM_TWEfile;
	int index_nominal_value_start = 0, index_nominal_value_end = 0, ready = 0, unit_end = 0;
	float nominal_value_float = 0.0, percentage_value_float = 0.0, tolerance_value_float = 0.0;
	ostringstream string_stream;
	fstream BOM_file, modified_BOM_file;
	/* --------------------------------------------------------------------------------------------------------------------------- */
	projPath = MARELLI_projects_path + projName;

	projBOMPath = projPath + "\\bom";
	projBOMfile = "BOM.txt";
	projBOM_TWEfile = projBOMPath + "\\BOM.txt";

	// Opening the output file in "OUTPUT" mode
	modified_BOM_file.open(projBOM_TWEfile.c_str(), ios::out);
	BOM_file.open(projBOMfile.c_str(), ios::in);

	//try {
	while (getline(BOM_file, component_line)) {

		string REF, LABEL, TOL, SHAPE, PARTNUMBER, ROTATION, POLARITY, VALUE, PTOL, NTOL;
		string newLABEL;
		vector<string> vectorLine;
		vector<string> vectorLabel;

		/* Parsing component line into a vector of string */
		vectorLine = parseLineByDelimiter(component_line, '\t');

		/* Taking just needed fields of the line */
		REF = getVectorElement(vectorLine, 0);	// OK
		LABEL = getVectorElement(vectorLine, 1);	// to be processed
		TOL = getVectorElement(vectorLine, 2);	// OK
		SHAPE = getVectorElement(vectorLine, 3);	// OK
		PARTNUMBER = getVectorElement(vectorLine, 4);	// OK
		ROTATION = getVectorElement(vectorLine, 7);	// OK
		POLARITY = getVectorElement(vectorLine, 8);	// OK
		
		/* Processing LABEL to take nominal value */
		LABEL = stringReplace(LABEL, ".", "");
		LABEL = stringReplace(LABEL, "+-", "_");
		LABEL = stringReplace(LABEL, "+", "_");
		vectorLabel = parseLineByDelimiter(LABEL, '_');
		VALUE = getVectorElement(vectorLabel, 2);
		if (VALUE.find_first_not_of("0123456789") == 0)
			VALUE = "";

		/* Building up the PTOL and NTOL fields */
		if (TOL != "" && TOL != "-") {
			PTOL = "+" + TOL;
			NTOL = "-" + TOL;
		}

		/* Adapt the value unit to TWE needs */
		VALUE = stringReplace(VALUE, "OH", "Ohm");
		VALUE = stringReplace(VALUE, "KO", "KOhm");
		VALUE = stringReplace(VALUE, "MO", "MOhm");
		VALUE = stringReplace(VALUE, "NF", "nF");
		VALUE = stringReplace(VALUE, "PF", "pF");
		VALUE = stringReplace(VALUE, "UF", "uF");
		VALUE = stringReplace(VALUE, "mhz", "MHz");

		/* Writing into new BOM file the interested fields */
		modified_BOM_file << REF << "\t" << PARTNUMBER << "\t" << VALUE << "\t" << NTOL << "\t" << PTOL  << "\t" << SHAPE << "\t" << ROTATION << endl;
	}

	BOM_file.close();
	modified_BOM_file.close();
	cout << projBOMPath << "\\BOM.txt added." << endl;
	
}
void createProjEnv() {
	/* Inform user about what has to be done before proceeding */
	cout << "Locate : " << endl << "- BOM.txt" << endl << "- CAD.pcb" << endl << "within the same folder from which this script has been launched." << endl << endl;
	cout << "Insert Project name : ";
	cin >> projName;

	/* Creating path based on project Name */
	projPath = MARELLI_projects_path + projName;
	projBOMPath = projPath + "\\bom";
	projCADPath = projPath + "\\cad";

	/* Create projDir*/
	if (_mkdir(projPath.c_str())){
		cout << "Couldn't create " << projPath << " directory." << endl;
		cout << endl << "Project environment can not be created." << endl << endl;
		return;
	}
		
	else
		cout << projPath << " directory successfully created." << endl;

	/* Create folder for BOM import */
	if (_mkdir(projBOMPath.c_str()))
		cout << "Couldn't create " << projBOMPath << " directory." << endl;
	else {
		cout << projBOMPath << " directory successfully created." << endl;
		// Format BOM file and move it into BOM folder
		if (fs::exists("BOM.txt")) {
			createTWE_BOM();
		}
		else {
			cout << "BOM.txt not present in this folder." << endl;
			fs::remove_all(projPath.c_str());
			cout << endl << "Project environment can not be created." << endl << endl;
			return;
		}

		// Move BOM grammar file into BOM folder
		if (fs::exists(MARELLI_custom_path + "\\BOM.grm")) {
			fs::copy(MARELLI_custom_path + "\\BOM.grm", projBOMPath + "\\BOM.grm");
			cout << projBOMPath << "\\BOM.grm added." << endl;
		}
		else {
			cout << "Unable to find BOM.grm file." << endl;
			fs::remove_all(projPath.c_str());
			cout << endl << "Project environment can not be created." << endl << endl;
			return;
		}
			
	}
	
	/* Create folder for CAD import */
	if (_mkdir(projCADPath.c_str()))
		cout << "Couldn't create " << projCADPath << " directory." << endl;
	else {
		cout << projCADPath << " directory successfully created." << endl;
		// move CAD file into CAD folder
		if (fs::exists("PCB.cad")) {
			fs::copy("pcb.cad", projCADPath + "\\pcb.cad");
			cout << projCADPath << "\\pcb.cad added." << endl;
		}
		else {
			cout << "PCB.cad not present in this folder." << endl;
			fs::remove_all(projPath.c_str());
			cout << endl << "Project environment can not be created." << endl;
			return;
		}
	}

	/* Create TWE .aa file */
	if (fs::exists(MARELLI_custom_path + "\\virginProject.aa")) {
		fs::copy(MARELLI_custom_path + "\\virginProject.aa", projPath + "\\" + projName + ".aa");
		cout << projPath << "\\" << projName << ".aa added." << endl;
	}
	else {
		cout << "Unable to find virginProject.aa into CUSTOM MARELLI folder." << endl;
		fs::remove_all(projPath.c_str());
		cout << endl << "Project environment can not be created." << endl;
		return;
	}

	system(("start " + MARELLI_projects_path + projName + "\\" + projName + ".aa").c_str());
}
void pullMasterLib() {
	if (fs::exists("\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\masterlib")) {
		if (fs::exists(disk + ":\\TestWay\\Data\\MARELLI\\LIB1")) {
			fs::copy("\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\masterlib", disk + ":\\TestWay\\Data\\MARELLI\\LIB1");
			cout << "Master library has been pulled to local." << endl;
		}
		else
			cout << "Problem accessing local master library." << endl;
	}
	else {
		cout << "Problem accessing remote master library." << endl;
	}
}
void pushMasterLib() {
	char confirm;
	cout << "!!! ATTENTION !!!" << endl;
	cout << "PUSH is an operation which overwrites the remote content." << endl;
	cout << "Are you sure to continue? Y / N" << endl;
	cout << "Answer : ";
	cin >> confirm;
	
	if (confirm == 'Y') {
		if (fs::exists("\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\masterlib")) {
			if (fs::exists(disk + ":\\TestWay\\Data\\MARELLI\\LIB1")) {
				fs::copy(disk + ":\\TestWay\\Data\\MARELLI\\LIB1", "\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\masterlib");
				cout << "Master library has been pushed to remote." << endl;
			}
			else
				cout << "Problem accessing local master library." << endl;
		}
		else {
			cout << "Problem accessing remote master library." << endl;
		}
	}
	else {
		cout << "Redirected to main menu." << endl;
	}

}
void pullModelLib() {
	if (fs::exists("\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\modellib")) {
		if (fs::exists(disk + ":\\TestWay\\Data\\MARELLI\\MODELS")) {
			fs::copy("\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\modellib", disk + ":\\TestWay\\Data\\MARELLI\\MODELS");
			cout << "Model library has been pulled to local." << endl;
		}
		else
			cout << "Problem accessing local model library." << endl;
	}
	else {
		cout << "Problem accessing remote model library." << endl;
	}
}
void pushModelLib() {
	char confirm;
	cout << "!!! ATTENTION !!!" << endl;
	cout << "PUSH is an operation which overwrites the remote content." << endl;
	cout << "Are you sure to continue? Y / N" << endl;
	cout << "Answer : ";
	cin >> confirm;

	if (confirm == 'Y' || confirm == 'y') {
		if (fs::exists("\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\modellib")) {
			if (fs::exists(disk + ":\\TestWay\\Data\\MARELLI\\MODELS")) {
				fs::copy(disk + ":\\TestWay\\Data\\MARELLI\\MODELS", "\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\modellib");
				cout << "Model library has been pushed to remote." << endl;
			}
			else
				cout << "Problem accessing local model library." << endl;
		}
		else {
			cout << "Problem accessing remote model library." << endl;
		}
	}
	else {
		cout << "Redirected to main menu." << endl;
	}

}
void pullProject() {
	cout << "Insert Project name : ";
	cin >> projName;

	if (fs::exists("\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\projects\\"+projName)) {
		if (fs::exists(disk + ":\\TestWay\\Data\\MARELLI\\PROJECTS\\" + projName)) {
			// If exists, copy the content
			fs::copy("\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\projects\\"+projName, disk + ":\\TestWay\\Data\\MARELLI\\PROJECTS\\"	+projName);
			cout << "The "+ projName +" project has been pulled to local." << endl;
		}
		else {
			// If not exists, create firstly the folder and then proceed
			_mkdir((disk + ":\\TestWay\\Data\\MARELLI\\PROJECTS\\" + projName).c_str());
			fs::copy("\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\projects\\" + projName, disk + ":\\TestWay\\Data\\MARELLI\\PROJECTS\\"+ projName);
			cout << "The " + projName + " project has been pulled to local." << endl;
		}
			
	}
	else {
		cout << "Problem accessing remote "+ projName + " project" << endl;
	}
}
void pushProject() {
	char confirm;
	cout << "!!! ATTENTION !!!" << endl;
	cout << "PUSH is an operation which overwrites the remote content." << endl;
	cout << "Are you sure to continue? Y / N" << endl;
	cout << "Answer : ";
	cin >> confirm;

	cout << "Insert Project name : ";
	cin >> projName;

	if (confirm == 'Y' || confirm == 'y') {
		if (fs::exists("\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\projects\\" + projName)) {
			if (fs::exists(disk + ":\\TestWay\\Data\\MARELLI\\PROJECTS\\" + projName)) {
				// If exists, copy the content
				fs::copy(disk + ":\\TestWay\\Data\\MARELLI\\PROJECTS\\" + projName, "\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\projects\\" + projName);
				cout << "The " + projName + " project has been pushed to remote." << endl;
			}
			else
				cout << "Problem accessing local model library." << endl;
		}
		else {
			// If not exists, create firstly the folder and then proceed
			if (_mkdir(("\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\projects\\" + projName).c_str())) {
				cout << "Problem accessing to remote folder." << endl;
				return;
			}

			fs::copy(disk + ":\\TestWay\\Data\\MARELLI\\PROJECTS\\" + projName, "\\\\Itvnr02fs3.mmemea.marelliad.net\\share\\TEP\\testway\\projects\\" + projName);
			cout << "The " + projName + " project has been pushed to remote." << endl;
		}
	}
	else {
		cout << "Redirected to main menu." << endl;
	}

}
string stringReplace(const string& str, const string& match, const string& replacement) {
	size_t pos = 0;
	string newstr = str;
	//cout << "replace " << endl;
	while ((pos = newstr.find(match, pos)) != str.npos){
		newstr.replace(pos, match.length(), replacement);
		pos += replacement.length();
	}
	return newstr;
}
string whichLocalDisk() {
	string localDisk;
	cout << "Insert the Local disk label where TestWay has been installed (i.e. C or D)" << endl;
	cout << "Local Disk : ";
	cin >> localDisk;

	return localDisk;
}
vector<string> parseLineByDelimiter(string line, char delimiter) {
	vector<string> arrayField;
	int foundPos = 0;
	int newPos = 0;
	//cout << "parse" << endl;
	while ((foundPos = line.find_first_of(delimiter, newPos)) != line.npos) {
		arrayField.push_back(line.substr(newPos, foundPos - newPos));
		newPos = foundPos + 1;
	}
	arrayField.push_back(line.substr(newPos));

	return arrayField;
}
void printVector(vector<string> vec) {
	vector<string>::iterator it;
	for (it = vec.begin(); it != vec.end(); it++) 
		cout << *(it) << "\t";
	cout << endl;
}
string getVectorElement(vector<string> vec, int posField) {
	vector<string>::iterator it = vec.begin();
	string retString;
	int curPos = 0;
	//cout << "get " << endl;
	for (it = vec.begin(); it != vec.end(); it++) {
		if (curPos == posField)
			return *(it);
		curPos += 1;
	}
	return "";
}
void deleteProjEnv() {
	cout << "Insert Project name : ";
	cin >> projName;

	projPath = MARELLI_projects_path + projName;
	if (fs::exists(projPath)) {
		fs::remove_all(projPath.c_str());
		cout << endl << "Project environment has been removed." << endl << endl;
	}
	else
		cout << endl << "Project does not exist." << endl << endl;
	
}